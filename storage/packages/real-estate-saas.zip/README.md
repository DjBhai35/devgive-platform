﻿# Complete Real Estate Marketplace SaaS Script

Production ready real-estate portal script featuring:
* Interactive Mapbox coordinate search
* Vendor & Agent listings
* Subscription plans & featured tiers
* Automated leads & inquiry management

## Installation
```bash
npm install
npx prisma generate
npm start
```
