﻿const express = require('express');
const app = express();
app.use(express.json());

app.get('/api/properties', (req, res) => {
  res.json({ properties: [] });
});

app.listen(5000, () => console.log('Real Estate API running on port 5000'));
