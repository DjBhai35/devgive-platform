﻿import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export function middleware(req: NextRequest) {
  const hostname = req.headers.get('host') || '';
  const currentHost = process.env.NODE_ENV === 'production' 
    ? hostname.replace(`.${process.env.ROOT_DOMAIN}`, '') 
    : hostname.replace('.localhost:3000', '');

  if (currentHost && currentHost !== 'localhost:3000') {
    return NextResponse.rewrite(new URL(`/storefront/${currentHost}${req.nextUrl.pathname}`, req.url));
  }
  return NextResponse.next();
}
