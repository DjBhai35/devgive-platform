﻿# Multi-Tenancy eCommerce SaaS Engine â€“ Automated Subdomains & Multi-Database Architecture

Version 2.4.0 | Production Release

## Architecture Overview
* **Automated Subdomains**: Dynamic routing using wildcard DNS and Next.js middleware.
* **Multi-Database Support**: Separate tenant databases for complete isolation and compliance.
* **POS & Inventory**: Real-time barcode scanning and stock sync.
* **20+ Payment Gateways**: Built-in support for Stripe, PayPal, Razorpay, Crypto, and Manual Transfers.

## Getting Started
1. Run `npm install`
2. Configure `.env` with database connection pool.
3. Run `npx prisma db push`
4. Run `npm run dev`
