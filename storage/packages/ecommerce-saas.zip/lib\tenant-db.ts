﻿import { PrismaClient } from '@prisma/client';

const tenantClients: Record<string, PrismaClient> = {};

export function getTenantPrisma(databaseUrl: string): PrismaClient {
  if (!tenantClients[databaseUrl]) {
    tenantClients[databaseUrl] = new PrismaClient({
      datasources: { db: { url: databaseUrl } }
    });
  }
  return tenantClients[databaseUrl];
}
