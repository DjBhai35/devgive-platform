﻿class GridStrategy:
    def __init__(self, upper_bound: float, lower_bound: float, grids: int):
        self.upper_bound = upper_bound
        self.lower_bound = lower_bound
        self.grids = grids
        self.step = (upper_bound - lower_bound) / grids

    def calculate_levels(self):
        return [self.lower_bound + (i * self.step) for i in range(self.grids + 1)]
