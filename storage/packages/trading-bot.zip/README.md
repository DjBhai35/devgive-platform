﻿# Crypto Trading Bot Platform with Automated Deposits and Withdrawals

Automated quantitative trading engine featuring:
* Multi-chain wallet listeners (EVM, Tron, Solana)
* Grid trading, DCA, and copy-trading modules
* Binance & Bybit connector with subaccount management
* Real-time position replication and stop-loss mechanisms

## Run locally
```bash
pip install -r requirements.txt
python main.py
```
