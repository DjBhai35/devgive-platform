﻿import uvicorn
from fastapi import FastAPI

app = FastAPI(title="Quantitative Trading Bot Platform")

@app.get("/")
def read_root():
    return {"status": "online", "engine": "algorithmic-grid-v2"}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
